/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int Present_Amount,Amount_Deposited,Past_Month,Amount_Withdraw,Annual_interest,Monthly_interest;
    cout<<"Present_Amount=";
    cin>>Present_Amount;
    cout<<"Amount_Deposited = ";
    cin>>Amount_Deposited;
    Present_Amount = Present_Amount+Amount_Deposited;
    cout<<"Remaining Balance = "<<Present_Amount<<endl;
    cout<<"Amount_Withdraw = ";
    cin>>Amount_Withdraw;
    cout<<"Remaining balance = "<<Present_Amount- Amount_Withdraw<<endl;
    cout<<"Annual_interest = ";
    cin>>Annual_interest;
      cout<<"Past month = ";
    cin>>Past_Month;
    Monthly_interest = Annual_interest/12;
    for(int i =1; i<=Past_Month;i++)
    Monthly_interest = Monthly_interest*i;
    cout<<"Present_Amount = "<<Monthly_interest*Present_Amount<<endl;
    cout<<"Amount_Deposited = "<<Amount_Deposited<<endl<<"Amount_Withdraw = "<<Amount_Withdraw<<endl;
    cout<<" Monthly_interest in % = "<<Monthly_interest<<endl;
    return 0;
}

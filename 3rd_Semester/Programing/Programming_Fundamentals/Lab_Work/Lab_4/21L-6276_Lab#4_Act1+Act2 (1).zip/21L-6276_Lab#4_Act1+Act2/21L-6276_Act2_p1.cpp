#include <iostream>
using namespace std;
int main()
{
        int  num1 = 2, num2 = 5;
        int n = 0;
        cout << "Enter te terms of series:";
        cin >> n;

        for (int i = 0; i <= n-1; i++)
		{
                if (i == 0)
					{
							cout << num1;
					}
                else if (i == 1)
					{
							cout << ",-" << num2;
					}
                else if (i % 2 == 0 )
					{
							num1+=2;
							cout << ",+" << num1;
					}
                else if (i % 2 != 0)
					{
							num2 += 5;
							cout << ",-" << num2;
					}
        }
		system("pause");
        return 0;
}
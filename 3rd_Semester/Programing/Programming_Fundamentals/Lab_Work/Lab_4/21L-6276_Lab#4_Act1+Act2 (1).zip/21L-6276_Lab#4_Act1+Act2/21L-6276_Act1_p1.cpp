#include <iostream>
using namespace std;
int main()
{
int H = 0;
	cout<<"enter the hight";
	cin>>H;
	for (int i = 0; i < H; i++)
	{
		for (int j = 0; j < 8; j++)
		{ 
			cout<<"*";
		}
		cout<<endl;
	}
	system("pause");
    return 0;
}

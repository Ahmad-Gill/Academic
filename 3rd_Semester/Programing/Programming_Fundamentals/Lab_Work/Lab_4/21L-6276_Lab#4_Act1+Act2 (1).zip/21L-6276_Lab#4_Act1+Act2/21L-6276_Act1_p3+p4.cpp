#include<iostream>
using namespace std;
int main()
{
	int H=0;
	 cout << "Enter the Height of Right Triangle: ";
        cin >> H;
        int d = 0;
        for (int i = 1; i <= H; i++)
        {
                for (int j = 1; j <= H - i; j++)
                {
                        cout << " ";
                }

                for (int j = 1; j <= i; j++)
                {
                        cout << "*";
                }
                cout << endl;
        }
		  cout << "Enter the Height of Hollow Right Triangle: ";
        cin >> H;

        for (int i = 1; i <= H; i++)
        {
                for (int j = 1; j <= H - i; j++)
					{
							cout << " ";
					}

					for (int j = 1; j <= i; j++)
                {

                        if (j == 1 || j == i || i == H)
						{
                                cout << "*";
                        }
                        else 
						{
                                cout << " ";
                        }
                }
                cout << endl;
        }
		system("pause");
		return 0;
}
#include <iostream>
using namespace std;
int main()
{
    int n, num1 = 0, num2 = 1, next = 0;

    cout << "Enter the terms of fibonacci series: ";
    cin >> n;

    cout << "The Fibonacci Series: ";

    for (int i = 1; i < n; ++i)
	{

        if (i == 2)
		{
            cout << num1 << ", ";

	    }
        if (i == 3)
		{
            cout << num2 << ", ";

        }
        next = num1 + num2;
        num1 = num2;
        num2 = next;

        cout << next << ", ";
    }
        return 0;
}


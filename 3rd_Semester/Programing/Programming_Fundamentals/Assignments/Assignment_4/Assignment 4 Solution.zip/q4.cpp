#include<iostream>
using namespace std;

int catsandMouse(int catA, int catB, int mouse) {

	int distA = mouse - catA, distB = mouse - catB;

	//Find absolute distances between the cats and the mouse
	if (distA < 0)
		distA *= -1;
	if (distB < 0)
		distB *= -1;

	//Cat A reaches mouse first
	if (distA < distB)
		return 1;
	//Cat B reaches mouse first
	if (distB < distA)
		return -1;
	//The mouse escapes
	if (distA == distB)
		return 0;
}

int main() {
	int catA, catB, mouse;
	cout << "Enter the positions of catA, catB and mouse: " << endl;
	cin >> catA >> catB >> mouse;

	//Keep taking input for positions until user enters all zeros
	while (catA != 0 || catB != 0 || mouse != 0) {
		int result = catsandMouse(catA, catB, mouse);

		if (result == 1)
			cout << "Cat A" << endl;
		else if (result == -1)
			cout << "Cat B" << endl;
		else if (result == 0)
			cout << "Mouse C" << endl;

		cout << endl << "Enter the positions of catA, catB and mouse: " << endl;
		cin >> catA >> catB >> mouse;
	}
	return 0;
}
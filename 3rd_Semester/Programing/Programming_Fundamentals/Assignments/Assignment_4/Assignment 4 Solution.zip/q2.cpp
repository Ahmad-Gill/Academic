#include<iostream>
using namespace std;

double SQRT(double R, double limit) {
	double left = 0, right = R + 1, mid;
	while (right - left > limit) {
		mid = (left + right) / 2;
		if (mid * mid > R)
			right = mid;
		else
			left = mid;
	}
	return (left + right) / 2;
}

int main() {
	double number = 0, limit;

	cout << "Enter limit on accuracy: ";
	cin >> limit;

	//Keeps taking input until user enters a negative number
	while (number >= 0) {
		cout << endl << "Enter number: ";
		cin >> number;
		if (number < 0)
			cout << "Program terminated" << endl;
		else
			cout << "Square root: " << SQRT(number, limit) << endl;
	}
	return 0;
}
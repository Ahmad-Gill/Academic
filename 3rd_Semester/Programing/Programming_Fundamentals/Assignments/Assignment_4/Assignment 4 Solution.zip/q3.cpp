#include<iostream>
using namespace std;

int fact(int N) {
	int factorial = 1;
	for (int i = 2; i <= N; i++) {
		factorial *= i;
	}
	return factorial;
}

int main() {
	int num = 0;
	while (num >= 0) {
		cout << "Enter a number: ";
		cin >> num;
		if (num < 0)
			cout << "Program terminated" << endl;
		else
			cout << "Factorial: " << fact(num) << endl;
	}
	return 0;
}
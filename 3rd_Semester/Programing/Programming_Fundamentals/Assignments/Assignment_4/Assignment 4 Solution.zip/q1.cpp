#include<iostream>
using namespace std;

int Euclid_GCD(int m, int n) {
	//If user enters negative values, function must return GCD of absolute values
	if (m < 0)
		m *= -1;
	if (n < 0)
		n *= -1;

	int remainder = m % n;
	while (remainder > 0) {
		m = n;
		n = remainder;
		remainder = m % n;
	}
	return n;
}

int main() {
	int num1 = 1, num2 = 1;
	//Keeps taking input until user enters 0 as first or second number
	while (num1 != 0 && num2 != 0) {
		cout << "Enter two numbers: ";
		cin >> num1 >> num2;
		if (num1 == 0 || num2 == 0)
			cout << "Program terminated" << endl;
		else
			cout << "GCD: " << Euclid_GCD(num1, num2) << endl;
	}
	return 0;
}